/*****************************
Name: Eli-Henry Dykhne
ID: 0996524
Date 26/11/2018
Assigment name: Assigment 4
Program: A4
******************************/




SAMPLE OPERATION START
__________________________________________________


cent@cent-ThinkPad-E570:~/Documents/CIS2520/A4$ ./A4
1. Initialization
2. Find
3. Insert
4. Remove
5. Check Height and Size
6. Find All (above a given frequency)
7. Exit
Enter a code (1-7) and hit Return
avl/> 1
1. Initialization
2. Find
3. Insert
4. Remove
5. Check Height and Size
6. Find All (above a given frequency)
7. Exit
Enter a code (1-7) and hit Return
avl/> 2
find key: bob
no_such_key
1. Initialization
2. Find
3. Insert
4. Remove
5. Check Height and Size
6. Find All (above a given frequency)
7. Exit
Enter a code (1-7) and hit Return
avl/> 2   
find key: flr662
key: flr662, frequency: 959
1. Initialization
2. Find
3. Insert
4. Remove
5. Check Height and Size
6. Find All (above a given frequency)
7. Exit
Enter a code (1-7) and hit Return
avl/> 3
insert key: bobby
1. Initialization
2. Find
3. Insert
4. Remove
5. Check Height and Size
6. Find All (above a given frequency)
7. Exit
Enter a code (1-7) and hit Return
avl/> 4
remove key: bobby
key: bobby, frequency: 0
1. Initialization
2. Find
3. Insert
4. Remove
5. Check Height and Size
6. Find All (above a given frequency)
7. Exit
Enter a code (1-7) and hit Return
avl/> 5
height: 13, size: 1483, total frequency: 174200
1. Initialization
2. Find
3. Insert
4. Remove
5. Check Height and Size
6. Find All (above a given frequency)
7. Exit
Enter a code (1-7) and hit Return
avl/> 6
frequency: 300
key: wrn99, frequency: 306
key: wrn96, frequency: 394
key: wrn81, frequency: 356
key: wrn70, frequency: 1242
key: wrn69, frequency: 893
key: wrn62, frequency: 315
key: wrn479, frequency: 525
key: wrn477, frequency: 380
key: wrn472, frequency: 988
key: wrn469, frequency: 1007
key: wrn468, frequency: 648
key: wrn467, frequency: 417
key: wrn458, frequency: 1167
key: wrn446, frequency: 491
key: wrn443, frequency: 839
key: wrn387, frequency: 301
key: wrn386, frequency: 332
key: wrn384, frequency: 647
key: wrn382, frequency: 337
key: wrn367, frequency: 671
key: wrn366, frequency: 704
key: wrn365, frequency: 854
key: wrn364, frequency: 395
key: wrn312, frequency: 1571
key: wrn28, frequency: 1225
key: wrn25, frequency: 1256
key: wrn24, frequency: 1057
key: wrn203, frequency: 2119
key: wrn202, frequency: 2221
key: wrn2, frequency: 1011
key: wrn127, frequency: 533
key: wrn112, frequency: 675
key: wrn104, frequency: 2715
key: flr997, frequency: 349
key: flr990, frequency: 740
key: flr987, frequency: 365
key: flr978, frequency: 742
key: flr934, frequency: 614
key: flr900, frequency: 865
key: flr9, frequency: 715
key: flr862, frequency: 823
key: flr836, frequency: 410
key: flr833, frequency: 879
key: flr830, frequency: 414
key: flr808, frequency: 325
key: flr795, frequency: 1147
key: flr772, frequency: 515
key: flr757, frequency: 1222
key: flr7, frequency: 383
key: flr662, frequency: 959
key: flr601, frequency: 400
key: flr549, frequency: 5590
key: flr548, frequency: 1709
key: flr360, frequency: 469
key: flr359, frequency: 818
key: flr351, frequency: 398
key: flr325, frequency: 330
key: flr312, frequency: 457
key: flr297, frequency: 658
key: flr2943, frequency: 708
key: flr2941, frequency: 1724
key: flr2939, frequency: 656
key: flr2937, frequency: 513
key: flr2936, frequency: 1110
key: flr2935, frequency: 980
key: flr293, frequency: 673
key: flr2910, frequency: 9790
key: flr2902, frequency: 491
key: flr286, frequency: 484
key: flr284, frequency: 499
key: flr2822, frequency: 1245
key: flr258, frequency: 570
key: flr255, frequency: 1337
key: flr2404, frequency: 487
key: flr2403, frequency: 509
key: flr2395, frequency: 761
key: flr2392, frequency: 843
key: flr234, frequency: 540
key: flr231, frequency: 1268
key: flr2273, frequency: 302
key: flr2255, frequency: 3645
key: flr2167, frequency: 391
key: flr2166, frequency: 388
key: flr2161, frequency: 336
key: flr2156, frequency: 409
key: flr2152, frequency: 325
key: flr2146, frequency: 319
key: flr2127, frequency: 367
key: flr2126, frequency: 649
key: flr2123, frequency: 375
key: flr2118, frequency: 431
key: flr2086, frequency: 423
key: flr1999, frequency: 900
key: flr1995, frequency: 1317
key: flr1976, frequency: 459
key: flr1971, frequency: 2702
key: flr1937, frequency: 1763
key: flr1935, frequency: 382
key: flr1918, frequency: 917
key: flr188, frequency: 326
key: flr1870, frequency: 371
key: flr1857, frequency: 3072
key: flr1856, frequency: 438
key: flr1854, frequency: 2063
key: flr1817, frequency: 1350
key: flr167, frequency: 653
key: flr1662, frequency: 2471
key: flr1661, frequency: 663
key: flr1657, frequency: 1510
key: flr1656, frequency: 499
key: flr1458, frequency: 951
key: flr1457, frequency: 1085
key: flr1455, frequency: 1200
key: flr1454, frequency: 1209
key: flr1453, frequency: 3085
key: flr1449, frequency: 367
key: flr1448, frequency: 390
key: flr1447, frequency: 495
key: flr1419, frequency: 329
key: flr1316, frequency: 1361
key: flr1314, frequency: 409
key: flr117, frequency: 7458
key: flr112, frequency: 388
1. Initialization
2. Find
3. Insert
4. Remove
5. Check Height and Size
6. Find All (above a given frequency)
7. Exit
Enter a code (1-7) and hit Return
avl/> 7

__________________________________________________

SAMPLE OPERATION END